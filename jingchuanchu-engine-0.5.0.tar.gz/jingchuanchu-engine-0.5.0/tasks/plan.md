# 网页 2D 游戏应用框架实施计划

依据 [SPEC](../SPEC.md)。本文件管理执行顺序，具体契约只在模块规格维护；[todo](todo.md) 记录任务状态。实际完成状态见 todo，已有 0.4.0 不计入新模型完成度。

## 当前性能迭代：P01—P06

规格见 [performance-spec](performance-spec.md)。每项先通过对应行为检查，再单独测量；前项结果落入 todo 后进入后项，保留现有架构与所有公开入口。

| 顺序 | 任务                             | 主要范围                                               | 验证与产物                                                         |
| ---- | -------------------------------- | ------------------------------------------------------ | ------------------------------------------------------------------ |
| P01  | 固化当前起点与热路径基准         | benchmarks/hot-paths.ts、性能规格与记录                | Node 基准、native 对照与源码摘要，不改运行时代码                   |
| P02  | query 单份句柄快照与直接成员循环 | ecs/index.ts、ecs.test.ts                              | 查询增删/复用/空查询回归；query 与下游耗时                         |
| P03  | require 单次 sparse slot 定位    | ecs/index.ts、ecs.test.ts                              | undefined/缺失/陈旧句柄回归；require 与移动耗时                    |
| P04  | 动作定义条目复用和固定结构快照   | runtime/input-actions.ts、input-actions.test.ts        | 边沿、深冻结、旧快照与特殊动作名；输入空闲/持有耗时                |
| P05  | 矩形四角的标量包围体计算         | renderer-2d/collision.ts、collision.test.ts            | 变换/offset/直接修改回归；稀疏与同 X 分布耗时                      |
| P06  | 收敛与真实浏览器复测             | 上述受影响定向测试、现有 browser/native 基准、迭代报告 | 类型、公开入口、原始测量、像素等价与参考游戏检查；未覆盖项如实保留 |

前轮绘制队列优化与条件模板文档修复不重复实施。继续优化渲染缓存、改调度算法或新增 ECS API 不属于本轮范围，只有新证据与明确规格才另立任务。

## 2026-11-07 生产级落地：0.5.0 正式版

在 P06 基础上补齐开发者工具与测试覆盖，不改现有架构与公开 API。完成状态见 todo 的「0.5.0 生产级落地迭代」章节；基准数据见 artifacts/performance/final-0.5.0.json。

| 顺序 | 任务 | 主要范围 | 验证与产物 |
| ---- | ---- | -------- | ---------- |
| G01  | ECS bulkQuery API | ecs/index.ts、tests/ecs-bulk-query.test.ts | 16 个 ECS 测试；热路径基准对比 |
| G02  | 渲染管线集成 bulkQuery | renderer-2d/index.ts、rendering-updates.test.ts | 功能回归 + 微基准 |
| G03  | Transform 帧缓存 | renderer-2d/features.ts、collision.ts、index.ts | renderer/collision 定向测试；基准 |
| G04  | 运行时性能采集 | app/runtime/performance-monitor.ts | 9 个单元测试；<1ms/帧开销验证 |
| G05  | 调试性能面板 | app/runtime/perf-panel.ts、application.ts | 10 个单元测试 |
| G06  | 桌面浏览器测试矩阵 | tests/e2e/browser-matrix.test.ts、playwright.config.ts | 类型检查；框架验证（执行需服务器） |
| G07  | Node 端内存耐久测试 | scripts/verify/endurance-check.ts | npm run test:endurance；2.09 MB < 10 MB |
| G08  | ActionSampler 与碰撞微优化 | app/runtime/input-actions.ts、renderer-2d/collision.ts | 输入/碰撞定向测试；热路径对比 |

## 实施原则

以最小功能闭环逐步实现：先让一个有输入/输出/model 的组件可编译、可挂载，再扩展 Store 和页面；Canvas、主题和游戏常用能力随后接入，最后验证完整默认项目。旧入口和模板在新默认项目切换前保持可用。

每个任务限制在一个可验证行为和约 3—5 个源码/测试文件；确实超过范围时继续拆分，不一次生成完整运行时。模块方法实现后再导出，不能用空函数先宣称接口完成。测试只覆盖对应行为，已通过且未受影响的检查不重复执行。

新文件位置为 packages/app/runtime、app/application.ts、tooling 与定向测试。业务示例位于 templates/browser，不放入引擎包。实际实现中如需改变本次固定接口，先修改对应规格与示例，不新增同义 API 绕开问题。

## M1：响应式与一个可编辑组件

模块：reactive-core、component-model。任务 T01—T08。

先交付 signal/computed/effect/batch，再做输入/输出与实例生命周期、三文件编译、表达式类型诊断和 model。条件/列表/slot 在同一模板协议中实现，不能堆到旧 data-* 字符串绑定后面冒充新模型。

检查点：昵称组件的两个实例独立，输入、预览和可提交状态自动联动；父级重置可回写表单；坏 model 目标和事件负载在原模板定位；旧 defineView fixture 仍通过。该检查点前不切换默认模板。

## M2：应用作用域与业务 Store

模块：application-services、state-store。任务 T09—T12，依赖 M1。

应用和页面通过 owner 协议连接组件、Store 和服务，避免组件反向依赖应用实现。新 application 子入口在此形成可消费的组合入口，已有根入口保持旧契约。

检查点：两页共享同一应用 Store，两套挂载应用完全隔离；页面退出释放私有 Store；异步操作及 reset 后旧结果不能写回。组件通过选择读取获得展示值，不镜像整份全局状态。

## M3：页面导航与代码加载

模块：page-router。任务 T13—T16，依赖 M2。

按匹配/HistoryDriver → 导航提交 → 出口/页面作用域 → 懒加载/预加载实现。prepare 返回页面输入。使用注入 HistoryDriver 验证拒绝/取消及前进后退，不启动浏览器。

检查点：首页与设置页导航成立；预加载不实例化页面，模块与参数变化分别管理；快切、失败和旧页清理异常维持正确提交状态。Vite fixture 产生真正的动态页面 chunk。

## M4：资源与主题

模块：asset-loading、theme-assets。任务 T17—T19。

资源加载只依赖原有 Scope/AssetCache，可在 M1 后独立进行；主题依赖响应式。先证明分组加载、持有与错误，再做语义键和开发者主题覆盖。不要先写图标组件自己的全局 URL 缓存。

检查点：UI 和 Canvas 取得同一选定键的资源；从图集区域覆盖为普通图时没有旧 frame；取消一方不破坏其他持有者。界面可以呈现条目加载进度与失败。

## M5：页面内 2D 运行能力

模块：viewport-input、game-feedback、canvas-host。任务 T20—T24；host 依赖 M2/M4。

复用现有渲染器、SceneManager、固定步及输入模块，封装尺寸/动作/时间的所有权。完成 GameCanvas 后，再把手写 DOM 查找和坐标公式从新模板的应用配置中移除。

检查点：进入游戏页只有一个所属驱动；暂停仍可操作 HUD，离页释放活动，重开不累加实体/系统；可变 CSS 尺寸下指针逻辑坐标一致。参考项目的物理仍使用现有基础碰撞，不在此阶段引入完整物理引擎。

## M6：音频和进度保存

模块：audio、save-data。任务 T25—T28。

音频依赖 M4；保存依赖 M2，可分别实施。用注入音频/存储驱动验证锁定状态、音量和坏档处理，真实设备播放交给人工验收。保存字段显式选择，不把 Store 直接 JSON.stringify。

检查点：设置中的音量/静音和结算高分可恢复；失败不是“成功保存”，未解锁不是“成功播放”；退出页面不会留下声音或旧用户数据。

## M7：可选认证/权限

模块：auth-session、access-policy。任务 T29—T31；依赖 M2/M3。

这是可选支线，可在 M9 默认单机闭环之后完成，不阻塞 M8/M9 的无认证项目；不能为等待外部账号后端而停住单机能力开发。

依次实现会话恢复/失效、权限判断、守卫集成和带后端适配的示例。纯单机不等待账号模块，也不为所有项目生成登录目录。

检查点：匿名/恢复失败/无权限结果不同；禁止访问时不准备页面或启动场景；账号切换清理旧作用域和晚到结果；假后端拒绝绕过前端守卫的请求，不能用本地 loggedIn 标志代替。

## M8：CLI、构建和兼容消费

模块：project-tooling。任务 T32—T36；运行契约应已稳定。

先做版本化项目配置和根目录解析，再做创建/代码生成与 add。新旧 profile 分开识别，但共用实际可复用的路径/打包能力。旧 API 由专门消费 fixture 验证，不在新模板默认界面同时挂两套代码。

检查点：自定义 paths 和缺省目录均能生成，注册冲突不部分改文件；指定或全部包通过 vendor 安装，tooling 为开发依赖；新模板与旧消费者能同时通过各自 check。此阶段执行打包后的独立消费，不因文档编辑反复打包。

## M9：完整参考游戏

模块：reference-game。任务 T37—T44；依赖默认单机能力及 M8。

分页面/功能接入默认模板：应用外壳 → 首页/关卡 → HUD/游玩 → 设置 → 结算/保存 → 第二套主题与加载音频反馈。素材需明确许可，小型资源足以证明流程。

检查点：按 reference-game 的矩阵记录自动验证和人工未验收项；独立生成的项目无需编辑引擎内部文件即可 check/build。没有真实游玩证据时只标记静态闭环通过，不标记发布就绪。

## 命令与验证节奏

定向检查示例（实际执行与结果见 todo，避免重复运行未受影响的检查）：

```bash
npx tsx --conditions=source --test tests/reactivity.test.ts
npx tsx --conditions=source --test tests/component-runtime.test.ts tests/component-template.test.ts
npx tsx --conditions=source --test tests/router.test.ts tests/router-loading.test.ts
```

其他任务照 todo 指定的测试文件选择执行。类型/公开入口有变化时运行 npm run typecheck；保持现有 npm run test:api 的旧名称/入口检查，但不能把它替代签名/行为兼容 fixture。

默认模板切换后运行 npm run check:templates 与 npm run test:project；M8/M9 使用 npm run dist:release、npm run test:app:distribution，按变更补 npm run test:packages。新 application 子入口必须在仓库外通过 ESM 与 TS 消费验证。

浏览器验收独立列在 todo 的 H 项，由用户明确授权后进行。全量、负载和性能测量仅在具体问题或交付风险需要时执行，不作为每个小任务的固定流程。

## 风险与处理

| 风险                                   | 处理                                                      |
| -------------------------------------- | --------------------------------------------------------- |
| 新组件/路由语法与旧入口互相污染        | application 子入口、项目 profile 和新旧消费 fixture 隔离  |
| 模板表达式只靠字符串拼接“看起来有类型” | 生成虚拟 TS 并保留 HTML 源位置，负向类型 fixture 必须失败 |
| 动态 import 或音频 API 无法真正中断    | 区分停止等待与停止底层任务，提交前检查 owner/代次         |
| 路由/场景/音频各自产生循环和清理       | 场景活动由 GameCanvas owner 统一持有，计时走固定步        |
| 主题替换改变图集或碰撞                 | 描述整体替换，显示资源与逻辑几何分离                      |
| 认证适配变成伪账号系统                 | 真实请求适配、服务端拒绝示例、单机可省略                  |
| 范围继续扩大导致交付延期               | 以参考游戏为上限；编辑器、3D、玩家换肤入口等留在范围外    |

## 历史清理边界

删除已被 SPEC 取代的长篇 RFC、旧项目结构规格、旧审查方向和重复的已完成任务清单。0.4.0 的 API 使用手册、更新/验证记录与已发布附件继续保留，它们描述已存在的行为，不再用来约束下一版架构。AGENTS 仅保留有效工作约定并指向 SPEC，不重复存放框架设计。
