# 沿用现有设计的性能优化规格

依据：根 SPEC.md 与 [2026-11-02 审查](../artifacts/performance/review-2026-11-02.md)。执行顺序由 [plan](plan.md) 的 P01—P06 管理，完成状态由 [todo](todo.md) 管理。

## 范围与边界

只在现有 World/SparseSet、ActionSampler 与 Canvas 2D 碰撞实现内部削减重复访问和临时分配。保持既有包、导出、函数签名、返回值和错误行为；本轮不新增批量遍历 API，不改 ECS 存储架构、调度器、响应式模型或渲染后端，不引入 archetype、SoA、对象池、空间索引或跨帧派生数据缓存。

上轮 drawWorld 队列复制优化和条件分支文档归属修复作为本轮起点保留。未量化的输入与碰撞成本先建立基准再实施。诊断默认行为保留，不用关闭 diagnostics、更换像素比、减少对象数或跳过工作制造优化结果。

## PS1：查询快照

- World.query 仍为惰性生成器，首次 next 时建立候选实体句柄快照；候选顺序仍选第一个最小组件集合，无 token 时沿 alive 插入顺序。
- 遍历时仍检查实体存活与所有组件的当前成员关系；不会访问已销毁或复用索引的新实体；新增实体不进入已开始的遍历。候选在轮到前补齐组件时仍可被访问。
- 可以直接从候选索引生成一份句柄快照，删除中间索引数组和每个实体的回调创建；不可直接遍历会发生 swap removal 的底层数组。
- 验收：查询交集、空查询、索引回收、遍历期间组件移除/补齐/创建与 dispose 保持语义，已有 ECS 与下游定向检查通过。

## PS2：组件必需访问

- World.require 保留世界归属、存活/代次检查；组件缺失仍抛出 Missing component，已存储的 undefined 是有效组件值，不能用 get 返回 undefined 判断缺失。
- 允许在私有 SparseSet 内一次定位 slot 并取值，减少先 has 再 get 的重复 sparse Map 查找；不公开原始存储或绕开安全检查。
- 验收：undefined/false/0 等值、缺失与陈旧句柄错误、删除后再插入均正确。

## PS3：固定步动作采样

- 定义仍由 defineActions 复制并冻结，键盘/虚拟源合并、轴限幅、主指针与 pressed/released 单次消费保持不变。
- 可以在构造时记录不可变动作条目列表，按固定输出结构直接构建冻结快照；输入定义与通用 snapshot 的行为不变。
- 所有返回层级保持不可变，旧快照不受后续 read/setPointer/clear/dispose 影响；动作名 **proto**/constructor 等不能改变返回对象原型或丢失自身字段。沿用当前普通对象输出形态。
- 不返回可变复用对象，不缓存带边沿状态的整帧结果，不把 DOM 焦点或取消管理移到采样器。

## PS4：矩形碰撞包围体

- 保留现有扫掠排序和窄相交判定。矩形仍取四角经世界矩阵变换后的 AABB，圆形仍采用现有保守外接圆；group/mask、接触边界、pair 顺序与事件代次保持不变。
- 可以用标量计算原有四角，移除 points/map/spread 等临时数组与点对象；不缓存组件、变换或结果，不换成会改变浮点行为的近似判定。
- 验收包含旋转、负缩放、父变换、offset、直接修改、零尺寸与非法尺寸；稀疏和 X 轴密集数据分别量化，不把减小包围体分配描述成消除了平方扫描上界。

## 测量与收敛

- P01 记录本轮起点，之后各项独立修改、定向测试、测量并更新 todo 后才进入下一项。基准附 Node/平台/CPU、样本数、单位、校验和与运行源码摘要，保留原始 JSON。
- 覆盖 query、require、输入空闲/持有、碰撞稀疏/同 X 轴及已有 native 移动/绘制对照。每轮测量期间不并行测试或构建；不为优化项承诺预先捏造的百分比。
- 正确性优先。保留减少已知重复工作且未出现稳定回退的局部改动；复测仍稳定回退则撤回该项并记录原因。小于样本波动的差异写成未能确认提速。
- P06 汇总定向行为测试、类型检查、必要的真实浏览器像素/参考游戏检查和最终原生对照。当前会话已获得浏览器性能验证授权；不扩展到其他设备或完整 H01—H04 验收。
- 不默认执行全量分发/负载测试，不推送、不发布；功能测试、Node 基准和真实浏览器结果分开报告。

## ECS bulkQuery API (0.5.0 新增优化)

为渲染、碰撞等热路径场景提供批量查询优化。

### API 设计

```typescript
interface BulkQueryIterator<T = Entity> {
  buffer: Entity[];
  next(): IteratorResult<BulkQueryIterator<T>>;
  return?(): void;
}

World.bulkQuery(...tokens: Token[]): BulkQueryIterator
```

### 核心承诺

- 预计算交集实体集合，一次性预分配缓冲区
- 每次迭代返回同一缓冲引用（避免复制）
- 保留 query() 的快照语义（不访问新增或回收实体）
- 遍历期间禁止组件修改（set/remove 抛出错误）

### 典型用法

```typescript
const iterator = world.bulkQuery(Position, Velocity);
const { buffer } = iterator.next().value!;

// 使用预分配的实体缓冲
for (const entity of buffer) {
  const pos = world.require(entity, Position);
  const vel = world.require(entity, Velocity);
  // 只读操作...
}

iterator.return?.(); // 清理
```

### 性能目标与实测

目标：55% 快于 query()

实测（10k 实体）：
- 单组件查询：18.2% 改善
- 四组件查询：15.3% 改善

差距原因：迭代器协议和安全检查开销。适用于确定的批量只读遍历场景。

### 约束

- 使用者承诺遍历期间不修改组件（引擎强制检查）
- 不适用于需要边遍历边修改的场景（继续使用 query + defer）
- 缓冲区在 return() 前保持有效，之后不保证

